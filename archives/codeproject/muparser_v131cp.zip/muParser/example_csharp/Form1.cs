using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace muWrapper
{
    public partial class Form1 : Form
    {
      private Parser m_parser;
      private List<String> m_history;
      private int m_histLine;

      private ParserVariable m_val1 = new ParserVariable(0);
      private ParserVariable m_val2 = new ParserVariable(0);
      private ParserVariable m_ans = new ParserVariable(0);

      public Form1()
      {
        InitializeComponent();

        cbDec.SelectedIndex = 0;
        cbArg.SelectedIndex = 1;

        try
        {
          m_parser = new Parser();
          m_parser.DefineFun("fun1", new Parser.Fun1Delegate(fun1) );
          m_parser.DefineFun("fun2", new Parser.Fun2Delegate(fun2) );
          m_parser.DefineFun("fun3", new Parser.Fun3Delegate(fun3) );
          m_parser.DefineFun("fun4", new Parser.Fun4Delegate(fun4) );
          m_parser.DefineFun("fun5", new Parser.Fun5Delegate(fun5) );
          m_parser.DefineFun("prod", new Parser.MultFunDelegate(prod) );
          m_parser.DefineOprt("%", new Parser.Fun2Delegate(fun2), 2 );

          m_parser.DefinePostfixOprt("m", new Parser.Fun1Delegate(milli));
          m_parser.DefineInfixOprt("!", new Parser.Fun1Delegate(not), Parser.EPrec.prLOGIC);

          m_parser.DefineVar("ans", m_ans);
          m_parser.DefineVar("my_var1", m_val1);
          m_parser.DefineVar("my_var2", m_val2);
        }
        catch (ParserException exc)
        {
          DumpException(exc);
        }

        m_history = new List<String>();
      }

      public double prod(double[] a, int size)
      {
        meHistory.AppendText("demo function prod called.\n");

        double val = 1;
        for (int i = 0; i < size; ++i)
          val *= a[i];

        return val;
      }

      public double strFun1(String str, double val1)
      {
        return val1 * 2;
      }

      public double strFun2(String str, double val1, double val2)
      {
        return val1 + val2;
      }

      public double strFun3(String str, double val1, double val2, double val3)
      {
        return val1 + val2 + val3;
      }

      public double milli(double val1)
      {
        meHistory.AppendText("function \"milli\" called.\n");
        return val1 / 1000.0;
      }

      public double not(double val1)
      {
        meHistory.AppendText("function \"not\" called.\n");
        return (val1==0) ? 1 : 0;
      }

      public double fun1(double val1)
      {
        meHistory.AppendText("demo function fun1 called.\n");
        return val1 * 2;
      }

      public double fun2(double val1, double val2)
      {
        meHistory.AppendText("demo function fun2 called.");
        return val1 + val2;
      }

      public double fun3(double val1, double val2, double val3)
      {
        meHistory.AppendText("demo function fun3 called.");
        return val1 + val2 + val3;
      }

      public double fun4(double val1, double val2, double val3, double val4)
      {
        meHistory.AppendText("demo function fun4 called.");
        return val1 + val2 + val3 + val4;
      }

      public double fun5(double val1, double val2, double val3, double val4, double val5)
      {
        meHistory.AppendText("demo function fun5 called.");
        return val1 + val2 + val3 + val4 + val5;
      }

      private void Calc(String expr)
      {
        try
        {
          m_history.Add(expr);

          meHistory.SelectionColor = System.Drawing.Color.Blue;
          meHistory.AppendText(expr);
          meHistory.AppendText("\r\n");
          meHistory.SelectionColor = System.Drawing.Color.Black;

          m_parser.SetDecSep(cbDec.Text.ToCharArray()[0]); // default: "."
          m_parser.SetArgSep(cbArg.Text.ToCharArray()[0]); // default: ","
          m_parser.SetExpr(expr);

          m_ans.Value = m_parser.Eval();

          string result = Convert.ToString(m_ans.Value);
          meHistory.AppendText("ans = ");
          meHistory.AppendText(result);
          meHistory.AppendText("\r\n");
        }
        catch (ParserException exc)
        {
          DumpException(exc);
        }
      }

      private void DumpException(ParserException exc)
      {
        string sMsg;

        sMsg = "An error occured:\n";
        sMsg += string.Format("  Expression:  \"{0}\"\n", exc.Expression);
        sMsg += string.Format("  Message:     \"{0}\"\n", exc.Message);
        sMsg += string.Format("  Token:       \"{0}\"\n", exc.Token);
        sMsg += string.Format("  Position:      {0}\n", exc.Position);

        meHistory.SelectionColor = System.Drawing.Color.Red;
        meHistory.AppendText(sMsg);
        meHistory.SelectionColor = System.Drawing.Color.Black;

        meHistory.SelectionStart = meHistory.TextLength;
        meHistory.ScrollToCaret();
      }

      private void edExpr_KeyDown(object sender, KeyEventArgs e)
      {
          Keys iCode = e.KeyCode;
          String expr = edExpr.Text;

          switch(iCode)
          {
          case Keys.Return:
               {
                  Calc(expr);
             
                  if (expr.Length>=0)
                      m_history.Add(expr);
                  else
                      edExpr.Text = "";

                  meHistory.SelectionStart = meHistory.TextLength;
                  meHistory.ScrollToCaret();
               }
               break;

          case Keys.Up:
          case Keys.Down:
               {
                   m_histLine = Math.Max(0, Math.Min(m_history.Count - 1, m_histLine));

                   if (m_history.Count==0)
                       break;

                   edExpr.Text = m_history[m_histLine];
                   edExpr.Select(edExpr.Text.Length, 0);

                   m_histLine += (iCode == Keys.Up) ? -1 : 1;
               }
               break;
          } // switch keyvode
      }

      private void btnListConst_Click(object sender, EventArgs e)
      {
        try
        {
          string sMsg = "";

          Dictionary<string, double> mapConst = m_parser.GetConst();

          sMsg = "Defined constants:\n";
          foreach (KeyValuePair<string, double> item in mapConst) 
          {
            sMsg += item.Key + " = ";
            sMsg += item.Value;
            sMsg += "\n";
          }
          sMsg += "\n";

          meHistory.SelectionColor = System.Drawing.Color.Blue;
          meHistory.AppendText(sMsg);
          meHistory.SelectionColor = System.Drawing.Color.Black;
          meHistory.SelectionStart = meHistory.TextLength;
          meHistory.ScrollToCaret();
        }
        catch (ParserException exc)
        {
          DumpException(exc);
        }
      }

      private void btnListVar_Click(object sender, EventArgs e)
      {
        try
        {
          string sMsg = "";

          Dictionary<string, ParserVariable> map = m_parser.GetVar();

          sMsg = "Defined variables:\n";
          foreach (KeyValuePair<string, ParserVariable> item in map)
          {
            sMsg += item.Key;
            sMsg += string.Format(" = {0}", item.Value.Value);
            sMsg += "\n";
          }
          sMsg += "\n";
          meHistory.SelectionColor = System.Drawing.Color.Blue;
          meHistory.AppendText(sMsg);
          meHistory.SelectionColor = System.Drawing.Color.Black;
          meHistory.SelectionStart = meHistory.TextLength;
          meHistory.ScrollToCaret();
        }
        catch (ParserException exc)
        {
          DumpException(exc);
        }
      }

      private void btnListExprVar_Click(object sender, EventArgs e)
      {
        string sMsg = "Expression variables:\n";

        try
        {

          Dictionary<string, IntPtr> map = m_parser.GetExprVar();

          if (map.Count > 0)
          {
            foreach (KeyValuePair<string, IntPtr> item in map)
            {
              sMsg += item.Key;
              sMsg += string.Format(" (memory location: {0:X})", item.Value.ToInt64());
              sMsg += "\n";
            }
          }
          else
            sMsg += "none";

        }
        catch (ParserException /*exc*/)
        {
          sMsg += "none";
//          DumpException(exc);
        }

        sMsg += "\n";

        meHistory.SelectionColor = System.Drawing.Color.Blue;
        meHistory.AppendText(sMsg);
        meHistory.SelectionColor = System.Drawing.Color.Black;
        meHistory.SelectionStart = meHistory.TextLength;
        meHistory.ScrollToCaret();
      }

      private void cbDec_SelectedIndexChanged(object sender, EventArgs e)
      {
        meHistory.SelectionColor = System.Drawing.Color.Blue;
        meHistory.AppendText(String.Format("Decimal separator changed to \"{0}\"\n", cbDec.Text));
        meHistory.SelectionColor = System.Drawing.Color.Black;
      }

      private void cbArg_SelectedIndexChanged(object sender, EventArgs e)
      {
        meHistory.SelectionColor = System.Drawing.Color.Blue;
        meHistory.AppendText(String.Format("Argument separator changed to \"{0}\"\n", cbArg.Text));
        meHistory.SelectionColor = System.Drawing.Color.Black;
      }
    } // class Form1
} // namespace muWrapper