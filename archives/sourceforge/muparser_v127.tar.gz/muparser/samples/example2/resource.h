//{{NO_DEPENDENCIES}}
// Mit Microsoft Visual C++ generierte Includedatei.
// Verwendet von 'app.rc'
