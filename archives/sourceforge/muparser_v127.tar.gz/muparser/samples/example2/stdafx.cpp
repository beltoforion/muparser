// stdafx.cpp: Quelldatei, die nur die Standard-Includes einbindet
// ExampleGui.pch ist der vorkompilierte Header
// 'stdafx.obj' enth�lt die vorkompilierten Typinformationen

#include "stdafx.h"


