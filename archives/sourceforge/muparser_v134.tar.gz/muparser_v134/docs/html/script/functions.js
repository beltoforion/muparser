//--------------------------------------------------
//
// Bedingte darstellung des SourceForge logos
//
function SFLogo()
{
  document.write("<img src=\"http:\/\/sourceforge.net\/sflogo.php?group_id=137191&amp;type=5\" width=\"210\" height=\"62\" border=\"0\" alt=\"SourceForge.net Logo\" \/>");
}

//--------------------------------------------------
//
// Statcounter code erzeugen
//
function statCounter()
{
  // statcounter variablen
  document.write("<script type=\"text\/javascript\" language=\"javascript\">");
  document.write("var sc_project=671117;");
  document.write("var sc_partition=5; ");
  document.write("var sc_security=\"f3fad66c\";");
  document.write("<\/script>");

  var sc_project=671117;
  var sc_partition=5;
  var sc_security="f3fad66c";

	
  // statcounter script	
  document.write("<script type=\"text\/javascript\" language=\"javascript\" src=\"http:\/\/www.statcounter.com\/counter\/counter.js\">");
  document.write("<\/script>");
}

