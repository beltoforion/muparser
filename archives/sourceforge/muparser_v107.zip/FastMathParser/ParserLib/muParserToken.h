/*
  Copyright (C) 2004 Ingo Berg

  Permission is hereby granted, free of charge, to any person obtaining a copy of this 
  software and associated documentation files (the "Software"), to deal in the Software
  without restriction, including without limitation the rights to use, copy, modify, 
  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
  permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or 
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
  NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
*/
#ifndef PARSER_TOKEN_H
#define PARSER_TOKEN_H

#pragma warning (disable : 4786)

#include <cassert>
#include "muParserException.h"


namespace MathUtils
{

/** \brief Encapsulation of the data for a single formula token. 

  Formula token implementation. Part of the Math Parser Package.
  
  <pre>
  Formula tokens can be either one of the following:
    - value
    - variable
    - function
    - operator
	- postfix operator
  </pre>

  (C) 2004 Ingo Berg
  ingo_berg@gmx.de
*/
template<typename TBase>
class ParserToken
{
public:
    /** \brief Bytecode values.

        \attention The order of the operator entries must match the order in legalOprt!
	*/
	enum ECmdCode
    {
      cmLE     =  0,  ///< Operator item:  less or equal
      cmGE     =  1,  ///< Operator item:  greater or equal
      cmNEQ    =  2,  ///< Operator item:  not equal
      cmEQ     =  3,  ///< Operator item:  equals
      cmLT     =  4,  ///< Operator item:  less than
      cmGT     =  5,  ///< Operator item:  greater than
      cmADD    =  6,  ///< Operator item:  add
      cmSUB    =  7,  ///< Operator item:  subtract
      cmMUL    =  8,  ///< Operator item:  multiply
      cmDIV    =  9,  ///< Operator item:  division
      cmPOW    = 10,  ///< Operator item:  y to the power of ...
      cmAND    = 11,  ///< Operator item:  y to the power of ...
      cmOR     = 12,  ///< Operator item:  y to the power of ...
      cmBO     = 13,  ///< Operator item:  opening bracket
      cmBC     = 14,  ///< Operator item:  closing bracket
	  cmCOMMA  = 15,  ///< Operator item:  comma
      cmVAR,          ///< variable item
      cmVAL,          ///< value item
      cmFUNC,         ///< function item
	  cmPOSTOP,	   ///< post value unary operator	
	  cmINFIXOP,	   ///< post value unary operator	
      cmEND,          ///< end of formula 
	  cmUNKNOWN,      ///< uninitialized item
    };

    /** \brief Token flags. */
    enum ETokFlags
	{
		flVOLATILE = 1, ///< Mark a token that depends on a variable or a function that is not conservative
	};

private:
	ECmdCode m_iType;  ///< Type of the token
	TBase  m_fVal;     ///< Stores Token value; not applicable for all tokens
	void  *m_pTok;     ///< Stores Token pointer; not applicable for all tokens
	int  m_iArgCount;  ///< Valid only for function tokens; Number of function arguments
	int  m_iFlags;      
    int  m_iDep;       ///< Token depends on a variable token and is connected with operator of this priority
    bool m_bAllowOpti; ///< True if the token is optimizeable 

public:

    //---------------------------------------------------------------------------
    ParserToken()
    :m_iType(cmUNKNOWN)
    ,m_fVal(0)
    ,m_pTok(0)
    ,m_iArgCount(0)
    ,m_iFlags(0)
    ,m_iDep(999)
    {
    }

    //------------------------------------------------------------------------------
    /** \brief Create token from another one.
    
      Implemented by calling Assign(...)
    */
    ParserToken(const ParserToken &a_Tok)
    :m_iType(cmUNKNOWN)
    ,m_fVal(0)
    ,m_pTok(0)
    ,m_iArgCount(0)
    ,m_iFlags(0)
    ,m_iDep(999)
    {
        Assign(a_Tok);
    }
    //------------------------------------------------------------------------------
    /** \brief Make token a value token and set its value. */
    ParserToken(TBase a_fVal)
    :m_iType(cmVAL)
    ,m_fVal(a_fVal)
    ,m_pTok(0)
    ,m_iArgCount(0)
    ,m_iFlags(0)
    ,m_iDep(999)
    {
    }

    //------------------------------------------------------------------------------
    /** \brief Assignement operator. 
    
      Copy token state from another token and return this.
      Implemented by calling Assign(...)
    */
    ParserToken& operator=(const ParserToken &a_Tok)
    {
        Assign(a_Tok);
        return *this;
    }

    //------------------------------------------------------------------------------
    /** \brief Copy token information from argument. */
    void Assign(const ParserToken &a_Tok)
    {
        m_iType = a_Tok.m_iType;
        m_pTok = a_Tok.m_pTok;
        m_fVal = a_Tok.m_fVal;
        m_iArgCount = a_Tok.m_iArgCount;
        m_iFlags = a_Tok.m_iFlags;
        m_iDep = a_Tok.m_iDep;
    }

    //------------------------------------------------------------------------------
    void AddFlags(int a_iFlags)
    {
       m_iFlags |= a_iFlags;
    }

    //------------------------------------------------------------------------------
    /** \brief Check if a certain flag ist set. */
    bool IsFlagSet(int a_iFlags) const
    {
    #pragma warning( disable : 4800 )
    return (bool)(m_iFlags & a_iFlags);
    #pragma warning( default : 4800 ) // int: Variable set to boolean value (may degrade performance)
    }

    //------------------------------------------------------------------------------
    /** \brief currently unused. */
    void SetDep(int a_iOpPri)
    {
      m_iDep = a_iOpPri;
    }

    //------------------------------------------------------------------------------
    /** \brief currently unused. */
    int GetDep() const
    {
      return m_iDep;
    }

    //------------------------------------------------------------------------------
    /** \brief Assign a token type. 

    Token may not be of type value, variable or function. Those have seperate set functions. 

    \pre [assert] a_iType!=cmVAR
    \pre [assert] a_iType!=cmVAL
    \pre [assert] a_iType!=cmFUNC
    \post m_fVal = 0
    \post m_pTok = 0
    */
    ParserToken& Set(ECmdCode a_iType)
    {
        // The following types cant be set this way, they have special Set functions
        assert(a_iType!=cmVAR);
        assert(a_iType!=cmVAL);
        assert(a_iType!=cmFUNC);

        m_iType = a_iType;
        m_fVal = 0;
        m_pTok = 0;
        m_iFlags = 0;

        return *this;
    }

    //------------------------------------------------------------------------------
    /** \brief Make this token a value token. 
    
      Member variables not necessary for value tokens will be invalidated.
    */
    ParserToken& SetVal(TBase a_fVal)
    {
        m_iType = cmVAL;
        m_fVal = a_fVal;
        m_pTok = 0;
        m_iFlags = 0;
        return *this;
    }

    //------------------------------------------------------------------------------
    /** \brief make this token a variable token. 
    
      Member variables not necessary for variable tokens will be invalidated.
    */
    ParserToken& SetVar(TBase *a_pVar)
    {
        m_iType = cmVAR;
        m_fVal = 0;
        m_pTok = (void*)a_pVar;
        m_iFlags = 0;

        AddFlags(ParserToken::flVOLATILE);
        return *this;
    }

    //------------------------------------------------------------------------------
    ParserToken& SetFun(void *a_pFun, int a_iArgc, bool a_bAllowOpti = true)
    {
        m_pTok = a_pFun;
        m_iArgCount = a_iArgc;
        m_iType = cmFUNC;
        m_fVal = 0;
        m_iFlags = 0;
        
        if (a_bAllowOpti==false)
            AddFlags(flVOLATILE);

        return *this;
    }

    //------------------------------------------------------------------------------
    /** \brief Make token a unary post value operator. */
    ParserToken& SetPostOp(void *a_pPostOp)
    {
        m_pTok = a_pPostOp;
        m_iArgCount = 0;
        m_iType = cmPOSTOP;
        m_fVal = 0;
        m_iFlags = 0;
        return *this;
    }

    //------------------------------------------------------------------------------
    /** \brief Make token a unary post value operator. */
    ParserToken& SetInfixOp(void *a_pFun)
    {
        m_pTok = a_pFun;
        m_iArgCount = 0;
        m_iType = cmINFIXOP;
        m_fVal = 0;
        m_iFlags = 0;
        return *this;
    }

    //------------------------------------------------------------------------------
    /** \brief Return the token type. */
    ECmdCode GetType() const
    {
        return m_iType;
    }

    //------------------------------------------------------------------------------
    /** \brief Return the function address for function and operator tokens.
      \throw ParserException if token is no function or operator token
    */
    void* GetFuncAddr() const
    {
    if (!(m_iType==cmFUNC || m_iType==cmPOSTOP || m_iType==cmINFIXOP))
	    throw ParserException("internal error:  GetFuncAddr() called non function/postfix operator token.");

    return m_pTok;
    }

    //------------------------------------------------------------------------------
    /** \biref Get value of the token.
      
      Only applicable to variable and value tokens.
      \throw ParserException if token is no value/variable token.
    */
    TBase GetVal() const
    {
        switch (m_iType)
        {
          case cmVAL:  return m_fVal;
          case cmVAR:  return *((TBase*)m_pTok);
          default:
	             throw ParserException("internal error:  GetVal() called for non value token.");
        }
    }

    //------------------------------------------------------------------------------
    /** \brief Get address of a variable token.

      Valid only if m_iType==CmdVar.
      \throw ParserException if token is no variable token.
    */
    TBase* GetVar() const
    {
        if (m_iType!=cmVAR)
            throw ParserException("internal error:  Token::GetArgCount() called for non variable token.");

        return (TBase*)m_pTok;
    }

    //------------------------------------------------------------------------------
    /** \brief Return the number of function arguments. 

    Valid only if m_iType==CmdFUNC.
    */
    int GetArgCount() const
    {
        if (m_iType!=cmFUNC)
	        throw ParserException("internal error:  Token::GetArgCount() called for non function token.");

        return m_iArgCount;
    }
};

} // namespace MathUtils

#endif


