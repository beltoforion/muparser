/*   
  Copyright (C) 2004 Ingo Berg

  Permission is hereby granted, free of charge, to any person obtaining a copy of this 
  software and associated documentation files (the "Software"), to deal in the Software
  without restriction, including without limitation the rights to use, copy, modify, 
  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
  permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or 
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
  NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
*/
#include "muParserDebug.h"
#include "muParserToken.h"

#include <iostream>

using namespace std;


namespace MathUtils
{

void ParserDebug::DumpCmdCode(int *CmdCode)
{
  if (!CmdCode) 
  {
    cout << "No bytecode available\n";
    exit(-1);
  }

  int i = 0;

  while ( CmdCode[i] != token_type::cmEND )
  {
	cout << "IDX[" << CmdCode[i++] << "]\t";
	switch (CmdCode[i])
	{
    case token_type::cmVAL:
 	 	  cout << "VAL "; ++i;
		  cout << "[" << *( reinterpret_cast<double*>(&CmdCode[i]) ) << "]\n";
		  i+=2;
		  break;

    case token_type::cmVAR:
  	      cout << "VAR "; ++i;
		  cout << "[ADDR: 0x" << hex << CmdCode[i] << "]\n"; ++i;
  	      break;
			
    case token_type::cmFUNC:
		  cout << "CALL\t"; ++i;
		  cout << "[Arg:" << CmdCode[i] << "]"; ++i;
		  cout << "[ADDR: 0x" << hex << CmdCode[i] << "]\n"; ++i;
		  break;

	case token_type::cmPOSTOP:
	      cout << "POSTOP\t"; ++i;
		  cout << "[ADDR: 0x" << CmdCode[i] << "]\n"; ++i;
	  	  break;

	case token_type::cmINFIXOP:
	  	  cout << "INFIXOP\t"; ++i;
		  cout << "[ADDR: 0x" << CmdCode[i] << "]\n"; ++i;
	      break;

    case token_type::cmADD: cout << "ADD\n"; ++i; break;
    case token_type::cmAND: cout << "AND\n"; ++i; break;
    case token_type::cmOR:  cout << "OR\n";  ++i; break;
    case token_type::cmSUB: cout << "SUB\n"; ++i; break;
    case token_type::cmMUL: cout << "MUL\n"; ++i; break;
    case token_type::cmDIV: cout << "DIV\n"; ++i; break;
    case token_type::cmPOW: cout << "POW\n"; ++i; break;
	default: cout << "(unknown code: " << CmdCode[i] << ")\n"; ++i;	break;
	}
  }

  cout << "END" << endl;
}


void ParserDebug::StackDump(const ParserStack<token_type > &a_stVal, 
							const ParserStack<token_type > &a_stOprt)
{
  ParserStack<token_type> stOprt;
  ParserStack<token_type> stVal;

  int iErrc;

  stOprt = a_stOprt;
  stVal = a_stVal;

  cout << "\nValue stack:\n";
  while ( !stVal.empty() ) 
  {
    token_type val = stVal.pop(iErrc);
    cout << " " << val.GetVal() << " ";
  }
  cout << "\nOperator stack:\n";

  while ( !stOprt.empty() )
  {
     if (stOprt.top().GetType()<=13) 
	 {
		 cout << ParserBase::c_DefaultOprt[stOprt.top().GetType()] << " ";
	 }
     else
     {
		switch(stOprt.top().GetType())
		{
		case token_type::cmVAR:     cout << "VAR ";   break;
		case token_type::cmVAL:     cout << "VAL ";   break;
		case token_type::cmFUNC:    cout << "FUNC "; break;
		case token_type::cmPOSTOP:  cout << "POSTOP "; break;
		case token_type::cmEND:     cout << "END "; break;
		case token_type::cmUNKNOWN: cout << "UNKNOWN "; break;
		default:  cout << stOprt.top().GetType() << " ";  break;
		}
     }	
     stOprt.pop();
  }

  cout <<endl;
}


} // namespace MathUtils
