/*
  Copyright (C) 2004 Ingo Berg

  Permission is hereby granted, free of charge, to any person obtaining a copy of this 
  software and associated documentation files (the "Software"), to deal in the Software
  without restriction, including without limitation the rights to use, copy, modify, 
  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
  permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or 
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
  NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
*/
#ifndef MU_PARSER_TEST_H
#define MU_PARSER_TEST_H

#include <string>
#include <numeric> // for accumulate
#include "muParser.h"


namespace MathUtils
{

namespace Test
{

/** \brief Test cases for unit testing.

  (C) 2004 Ingo Berg
*/
class ParserTester // final
{
private:
	// Multiarg callbacks
	static double f1of1(double v) { return v;};
	
	static double f1of2(double v, double  ) {return v;};
	static double f2of2(double  , double v) {return v;};

	static double f1of3(double v, double  , double  ) {return v;};
	static double f2of3(double  , double v, double  ) {return v;};
	static double f3of3(double  , double  , double v) {return v;};
	
	static double f1of4(double v, double,   double  , double  ) {return v;}
	static double f2of4(double  , double v, double  , double  ) {return v;}
	static double f3of4(double  , double,   double v, double  ) {return v;}
	static double f4of4(double  , double,   double  , double v) {return v;}

	static double f1of5(double v, double,   double  , double  , double  ) { return v; }
	static double f2of5(double  , double v, double  , double  , double  ) { return v; }
	static double f3of5(double  , double,   double v, double  , double  ) { return v; }
	static double f4of5(double  , double,   double  , double v, double  ) { return v; }
	static double f5of5(double  , double,   double  , double  , double v) { return v; }

  static double Min(double a_fVal1, double a_fVal2) { return (a_fVal1<a_fVal2) ? a_fVal1 : a_fVal2; }
	static double Max(double a_fVal1, double a_fVal2) { return (a_fVal1>a_fVal2) ? a_fVal1 : a_fVal2; }
  static double Sum(const std::vector<double> &a_vArg) { return std::accumulate(a_vArg.begin(), a_vArg.end(), (double)0); };

  static double Rnd(double v);

	// postfix operator callback
	static double Milli(double v) { return v/1e3; }

	bool TestNames();
	bool TestSyntax();
	bool TestMultiArg();
	bool TestVolatile();
	bool TestPostFix();
	bool TestFormula();
	bool TestInfixOprt();
	bool TestVarConst();

public:
    typedef bool (ParserTester::*testfun_type)();

	ParserTester();
 ~ParserTester() {};
	ParserTester(const ParserTester&) {};
	void Run();
	void AddTest(testfun_type a_pFun);
  bool EqnTest(const std::string a_str, double a_fRes, bool a_fPass);

private:
	std::vector<testfun_type> m_vTestFun;
};

} // namespace Test

} // namespace MathUtils

#endif


