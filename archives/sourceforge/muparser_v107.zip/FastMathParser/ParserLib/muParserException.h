/*
  Copyright (C) 2004 Ingo Berg

  Permission is hereby granted, free of charge, to any person obtaining a copy of this 
  software and associated documentation files (the "Software"), to deal in the Software
  without restriction, including without limitation the rights to use, copy, modify, 
  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
  permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or 
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
  NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
*/
#ifndef MU_PARSER_EXCEPTION_H
#define MU_PARSER_EXCEPTION_H

#pragma warning (disable : 4786)

#include <stdexcept>
#include <string>


namespace MathUtils
{

/** \brief Error class of the parser. 

  Part of the math parser package.

  \author Ingo Berg
*/
class ParserException : public std::runtime_error
{
public:
  //------------------------------------------------------------------------------
    ParserException(const std::string &szMsg = "Parser:  Unspecified error.",
                    const std::string &szFormula = "(formula is not available)") 
  :std::runtime_error(szMsg)
  ,m_strFormula(szFormula)
  {
  }

  //------------------------------------------------------------------------------
  virtual ParserException::~ParserException() throw() {};
  
  //------------------------------------------------------------------------------
  void SetFormula(const std::string &a_strFormula)
  {
    m_strFormula = a_strFormula;
  }

  //------------------------------------------------------------------------------
  const std::string& GetFormula() const 
  {
	return m_strFormula;
  }

private:
    std::string m_strFormula;
};		

} // namespace MathUtils

#endif

