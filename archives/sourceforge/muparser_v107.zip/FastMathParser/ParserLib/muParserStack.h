/*
  Copyright (C) 2004 Ingo Berg

  Permission is hereby granted, free of charge, to any person obtaining a copy of this 
  software and associated documentation files (the "Software"), to deal in the Software
  without restriction, including without limitation the rights to use, copy, modify, 
  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
  permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or 
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
  NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
*/
#ifndef MU_PARSER_STACK_H
#define MU_PARSER_STACK_H

#pragma warning (disable : 4786)

#include <vector>
#include <stack>

#include "muParserException.h"


namespace MathUtils
{

/** \brief Parser stack. 

 Stack implementation based on a std::stack. The behaviour of pop() had been
 slightly changed in order to get an error code if the stack is empty.

 \author ingo berg (ingo_berg@gmx.de)
*/
template <typename TValueType>
class ParserStack : private std::stack<TValueType, std::vector<TValueType> >
{
#ifdef PARSER_DEBUG
  friend class Parser;
#endif

  private:
    typedef std::stack<TValueType, std::vector<TValueType> > base_type;

  public:	
	 
     //---------------------------------------------------------------------------
     /** \brief Pop a value from the stack.
     
       Unlike the standard implementation this function will return the value that
       is going to be taken from the stack.

       \throw ParserException in case the stack is empty.
       \sa pop(int &a_iErrc)
     */
	 TValueType pop()
     {
       if (empty())
         throw ParserException("stack is empty.");

       TValueType el = top();
       base_type::pop();
       return el;
     }

     //---------------------------------------------------------------------------
     /** \brief Pop a value from the stack. 
     
       If no value is present an error code will be set in this case
       a default constructed element will be returned.
       
       \param a_iErrc Error code; (0:operation succeeded  1:stack is empty)
       \throw nothrow
     */
     TValueType pop(int &a_iErrc)
     {
       a_iErrc = 0;

       if (empty())
       {
         a_iErrc = 1;
         return TValueType();
       }
      
       TValueType el(top());
       pop();           
      
       return el;
     }
/* Does not work with BCB
     using std::stack<TValueType, std::vector<TValueType> >::push;
     using std::stack<TValueType, std::vector<TValueType> >::size;
     using std::stack<TValueType, std::vector<TValueType> >::empty;
     using std::stack<TValueType, std::vector<TValueType> >::top;
 */
     void push(const TValueType& a_Val) { base_type::push(a_Val); }
     unsigned size() { return (unsigned)base_type::size(); }
     bool empty()    { return base_type::size()==0; }
     TValueType& top() { return base_type::top(); }
};


} // namespace MathUtils

#endif


