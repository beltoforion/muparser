/*
  Copyright (C) 2004 Ingo Berg

  Permission is hereby granted, free of charge, to any person obtaining a copy of this 
  software and associated documentation files (the "Software"), to deal in the Software
  without restriction, including without limitation the rights to use, copy, modify, 
  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
  permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or 
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
  NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
*/
#include "muParser.h"
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <memory>
#include <utility>
#include <vector>

#include "muParserToken.h"

using namespace std;


namespace MathUtils
{


const int ParserBase::c_iPointerSize = sizeof(void*);
const int ParserBase::c_iValueSize = sizeof(value_type);
    
char* ParserBase::c_DefaultOprt[]  = { "<=", ">=", "!=", "==", "<", ">", "+", "-", "*", "/",
                                       "^", "and", "or", "(", ")", ",", 0 };

char* ParserBase::c_NameChars = "0123456789_"
                                "abcdefghijklmnopqrstuvwxyz"
                                "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

char* ParserBase::c_OprtChars = "abcdefghijklmnopqrstuvwxyz"
                                "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                                "+-*/^?<>=#!$%&|~'_";

char* ParserBase::c_OprtCharsPrefix = "+-*/^?<>=#!$%&|~'_";

//------------------------------------------------------------------------------
/** \brief Constructor.
  \param a_szFormula the formula to interpret.
  \throw ParserException if a_szFormula is null.
*/
ParserBase::ParserBase()
:m_pParseFormula(0)
,m_iPos(0)
,m_pCmdCode(0)
,m_strFormula()
,m_FunDef()
,m_ConstDef()
,m_VarDef()
,m_UsedVar()
,m_PostOprtDef()
,m_InfixOprtDef()
,m_bOptimize(true)
,m_bUseByteCode(true)
,m_bIgnoreUndefVar(false)
,m_fZero(0)
{
  Check();
}

//---------------------------------------------------------------------------
/** \brief Copy constructor. 

 Implemented by calling Assign(a_Parser)
*/
ParserBase::ParserBase(const ParserBase &a_Parser)
:m_pParseFormula(&ParserBase::ParseString)
,m_iPos(0)
,m_pCmdCode(0)
,m_strFormula()
,m_FunDef()
,m_ConstDef()
,m_VarDef()
,m_UsedVar()
,m_PostOprtDef()
,m_InfixOprtDef()
,m_bOptimize(true)
,m_bUseByteCode(true)
,m_bIgnoreUndefVar(false)
,m_fZero(0)
{
  Assign(a_Parser);
}

//---------------------------------------------------------------------------
/** \brief Assignement operator. 

 Implemented by calling Assign(a_Parser)
*/
ParserBase& ParserBase::operator=(const ParserBase &a_Parser)
{
  Assign(a_Parser);
  return *this;
}


//---------------------------------------------------------------------------
/** \brief Check if the sizeof(value_type)==2*sizeof(int) && sizeof(void*)==sizeof(int).
 
 The checks will trigger asserts if they fail. It is absolutely necessary that the sizes
 have this relation unless the parser cant work properly!
*/
void ParserBase::Check() const
{
  // Parser only runs properly given the following preconditions:
  assert( sizeof(value_type)  == 2*sizeof(int) );
  assert( sizeof(value_type*) ==   sizeof(int) );
  assert( sizeof(void*)       ==   sizeof(int) );
}

//---------------------------------------------------------------------------
/** \brief Check if a name contains invalid characters. 

  \throw ParserException if the name contains invalid charakters.
*/ 
void  ParserBase::CheckName(const string_type &a_strName, const char * const a_szCharSet) const
{
  assert(a_szCharSet);

  if (!a_strName.length())
      Error("Identifier has zero length.");

  if (a_strName.length()!=strspn(a_strName.c_str(), a_szCharSet))
      Error("Variable names may only contain the following charakters: a-z, A-Z, 0-9, _");

  if (a_strName[0]>='0' && a_strName[0]<='9')
      Error("Name identifiers may not start with numbers.");
}

//---------------------------------------------------------------------------
/** \brief Copy state of a parser object to this. 

  Clears Variables and Functions of this parser.
  Copies the states of all internal variables.
  Resets parse function to string parse mode.

  \param a_Parser the source object.
*/
void ParserBase::Assign(const ParserBase &a_Parser)
{
  if (&a_Parser==this)
    return;

  // Don't copy bytecode instead cause the parser to create new bytecode 
  // by resetting the parse function.
  m_pParseFormula = &ParserBase::ParseString;
  
  m_iPos = a_Parser.m_iPos;
  m_strFormula = a_Parser.m_strFormula;     // Copy the formula
  m_FunDef = a_Parser.m_FunDef;             // Copy function definitions
  m_ConstDef = a_Parser.m_ConstDef;         // Copy user define constants
  m_VarDef = a_Parser.m_VarDef;             // Copy user defined variables
  m_UsedVar = a_Parser.m_UsedVar;           // Copy used map holding the used variables   
  m_PostOprtDef = a_Parser.m_PostOprtDef;   // post value unary operators
  m_InfixOprtDef = a_Parser.m_InfixOprtDef; // unary operators for infix notation
  m_bOptimize  = a_Parser.m_bOptimize;
  m_bUseByteCode = a_Parser.m_bUseByteCode;
  m_bIgnoreUndefVar = a_Parser.m_bIgnoreUndefVar;
}


//---------------------------------------------------------------------------
/** \brief Destructor. (trivial) */
ParserBase::~ParserBase()
{
  delete [] m_pCmdCode;
}


//---------------------------------------------------------------------------
/** \brief Initialize user defined functions. 
 
  Calls the virtual functions InitFun(), InitConst() and InitOprt().
*/
void ParserBase::Init()
{
  InitFun();
  InitConst();
  InitOprt();
}

//---------------------------------------------------------------------------
/** \brief Set Parser Variables. 

  Input will be provided as a map containing the names and pointers of the variables.

  \throw ParserException in case of an out of memory condition
*/
void ParserBase::SetVar(const varmap_type &a_vVar)
{
  m_VarDef = a_vVar;
  m_pParseFormula = &ParserBase::ParseString; // switch to string parse mode
}

//---------------------------------------------------------------------------
/** \brief Set user defined constants. */
void ParserBase::SetConst(const valmap_type &a_vConst)
{
  m_ConstDef = a_vConst;
  m_pParseFormula = &ParserBase::ParseString; // switch to string parse mode
}

//---------------------------------------------------------------------------
/** \brief Set the formula. 
    Triggers first time calculation thus the creation of the bytecode and 
    scanning of used variables.

    \param a_strFormula Formula as string_type
    \throw ParserException in case of syntax errors.
*/
void ParserBase::SetFormula(const string_type &a_strFormula)
{
  m_strFormula = a_strFormula;
  m_pParseFormula = &ParserBase::ParseString; // switch to string parse mode
}

//---------------------------------------------------------------------------
/** \brief Add a user defined unary function. 
    \post Will reset the Parser to string parsing mode.
*/
void ParserBase::AddFun(const string_type &a_strFun, fun_type1 a_pFun, bool a_bAllowOpt)
{
  if (a_pFun==0)
      Error("User defined function is null!");

  CheckName(a_strFun, c_NameChars);
  m_FunDef[a_strFun] = FunProt((void*)a_pFun, 1, a_bAllowOpt);
  m_pParseFormula = &ParserBase::ParseString;
}

//---------------------------------------------------------------------------
/** \brief Add a user defined function binary function. 
    \post Will reset the Parser to string parsing mode.
*/
void ParserBase::AddFun(const string_type &a_strFun, fun_type2 a_pFun, bool a_bAllowOpt)
{
  if (a_pFun==0)
    Error("User defined function is null!");

  CheckName(a_strFun, c_NameChars);
  m_FunDef[a_strFun] = FunProt((void*)a_pFun, 2, a_bAllowOpt);
  m_pParseFormula = &ParserBase::ParseString;
}

//---------------------------------------------------------------------------
/** \brief Add a user defined function binary function. 
    \post Will reset the Parser to string parsing mode.
*/
void ParserBase::AddFun(const string_type &a_strFun, fun_type3 a_pFun, bool a_bAllowOpt)
{
  if (a_pFun==0)
    Error("User defined function is null!");

  CheckName(a_strFun, c_NameChars);
  m_FunDef[a_strFun] = FunProt((void*)a_pFun, 3, a_bAllowOpt);
  m_pParseFormula = &ParserBase::ParseString;
}

//---------------------------------------------------------------------------
/** \brief Add a user defined function binary function. 
    \post Will reset the Parser to string parsing mode.
*/
void ParserBase::AddFun(const string_type &a_strFun, fun_type4 a_pFun, bool a_bAllowOpt)
{
  if (a_pFun==0)
    Error("User defined function is null!");

  CheckName(a_strFun, c_NameChars);
  m_FunDef[a_strFun] = FunProt((void*)a_pFun, 4, a_bAllowOpt);
  m_pParseFormula = &ParserBase::ParseString;
}

//---------------------------------------------------------------------------
/** \brief Add a user defined function binary function. 
    \post Will reset the Parser to string parsing mode.
*/
void ParserBase::AddFun(const string_type &a_strFun, fun_type5 a_pFun, bool a_bAllowOpt)
{
  if (a_pFun==0) 
      Error("User defined function is null!");

  CheckName(a_strFun, c_NameChars);
  m_FunDef[a_strFun] = FunProt((void*)a_pFun, 5, a_bAllowOpt);
  m_pParseFormula = &ParserBase::ParseString;
}

//---------------------------------------------------------------------------
void ParserBase::AddFun(const string_type &a_strFun, multfun_type a_pFun, bool a_bAllowOpt)
{
  if (a_pFun==0) 
      Error("User defined function is null!");
  
  CheckName(a_strFun, c_NameChars);
  m_FunDef[a_strFun] = FunProt((void*)a_pFun, -1, a_bAllowOpt);
  m_pParseFormula = &ParserBase::ParseString;
}

//---------------------------------------------------------------------------
/** \brief Add a user defined variable. 
    \post Will reset the Parser to string parsing mode.
    \pre [assert] a_fVar!=0
    \throw ParserException in case the name contains invalid signs.
*/
void ParserBase::AddVar(const string_type &a_strVar, value_type *a_pVar)
{
  if (a_pVar==0)
      Error("Address of user defined variable is null!");

  CheckName(a_strVar, c_NameChars);
  m_VarDef[a_strVar] = a_pVar;
  m_pParseFormula = &ParserBase::ParseString;
}

//---------------------------------------------------------------------------
/** \brief Add a user defined operator. 
    \post Will reset the Parser to string parsing mode.
*/
void ParserBase::AddPostfixOp(const string_type &a_strName, fun_type1 a_pOprt)
{
  if (a_pOprt==0)
      Error("User defined operator callback function is null!");

  CheckName(a_strName, c_OprtChars);
  m_PostOprtDef[a_strName] = a_pOprt;
  m_pParseFormula = &ParserBase::ParseString;
}

//---------------------------------------------------------------------------
/** \brief Add a user defined operator. 
    \post Will reset the Parser to string parsing mode.
*/
void ParserBase::AddPrefixOp(const string_type &a_strName, fun_type1 a_pOprt)
{
  if (a_pOprt==0)
    Error("User defined operator callback function is null!");

  CheckName(a_strName, c_OprtChars);
  m_InfixOprtDef[a_strName] = a_pOprt;
  m_pParseFormula = &ParserBase::ParseString;
}

//---------------------------------------------------------------------------
/** \brief Add a user defined constant. 
    \post Will reset the Parser to string parsing mode.
    \throw ParserException in case the name contains invalid signs.
*/
void ParserBase::AddConst(const string_type &a_strName, value_type a_fVal)
{
  CheckName(a_strName, c_NameChars);
  m_ConstDef[a_strName] = a_fVal;
  m_pParseFormula = &ParserBase::ParseString; 
}

//---------------------------------------------------------------------------
/** \brief Read a Token from String.
  \param a_iPos [in/out] Index from where to start reading, will be advanced after reading the token.
  \param a_iSynFlags [in/out] Flags that control which tokens are allowed her, and which will be allowed in the next step.
  \return token that has been read
*/
ParserBase::token_type ParserBase::ReadToken(int &a_iPos, int &a_iSynFlags) const
{
  std::stack<int> FunArgs;
  const char *szFormula = m_strFormula.c_str();

  while (szFormula[a_iPos]==' ') 
      ++a_iPos;

  token_type tok;

  // check for EOF
  if ( !szFormula[a_iPos] || szFormula[a_iPos] == '\n')
  {
    if ( a_iSynFlags & noEND )
      Error("Unexpected end of formula: ", 0);

    a_iSynFlags = 0;
    tok.Set(token_type::cmEND);
	return tok;
  }

  // Compare token with function and operator strings
  // check string for operator/function
  for (int i=0; c_DefaultOprt[i]; i++)
  {
 	int len = (int)strlen( c_DefaultOprt[i] );

	if (!strncmp(&szFormula[a_iPos], c_DefaultOprt[i], len))
	{
	  switch(i)
	  {
        case token_type::cmAND:
        case token_type::cmOR:
        case token_type::cmLT:
		case token_type::cmGT:
		case token_type::cmLE:
		case token_type::cmGE:
		case token_type::cmNEQ:  
		case token_type::cmEQ:
		case token_type::cmADD:
		case token_type::cmSUB:
		case token_type::cmMUL:
		case token_type::cmDIV:
		case token_type::cmPOW:
				if (a_iSynFlags & noOPT) 
                {
                  // Maybe its an infix operator not an operator
                  if ( IsInfixOpTok(a_iPos, tok) )
                  {
                    if (a_iSynFlags & noINFIXOP) Error("No unary operator expected:",  m_iPos);
                    a_iSynFlags = noPOSTOP | noINFIXOP | noOPT | noBC; 
                   	return tok;
                  }

                  Error("Unexpected operator: ", m_iPos);
                }

                a_iSynFlags  = noBC | noOPT | noCOMMA | noPOSTOP;
				a_iSynFlags |= ( (i != token_type::cmEND) && ( i != token_type::cmBC) ) ? noEND : 0;
				break;

		case token_type::cmCOMMA:
				if (a_iSynFlags & noCOMMA)
					Error("No \",\" expected:", m_iPos);
				
				a_iSynFlags  = noBC | noOPT | noEND | noCOMMA | noPOSTOP;
			    break;

		case token_type::cmBO:
				if (a_iSynFlags & noBO)
					Error("No \"(\" expected:", m_iPos);

				a_iSynFlags = noBC | noOPT | noEND | noCOMMA | noPOSTOP;
				break;

		case token_type::cmBC:
				if (a_iSynFlags & noBC)
				  Error("No \")\" expected: ", m_iPos);

				a_iSynFlags  = noBO | noVAR | noVAL | noFUN | noINFIXOP;
				break;
		
		default: 
                // The operator is listed in c_DefaultOprt, but not here. This is a bad thing...
			    Error("internal error while checking syntax:  unsupported operator used");
	  } // switch operator id

      a_iPos += len;
      return tok.Set( (token_type::ECmdCode)i );
	} // if operator string found
  } // end of for all operator strings

  // Read the next token from string
  if (IsFunTok(a_iPos, tok))
  {
    if (a_iSynFlags & noFUN) Error("No function expected: ", m_iPos);
	a_iSynFlags = noCOMMA | noBC | noFUN | noVAR | noVAL | noOPT | noPOSTOP | noEND;
	return tok;
  }

  // check String for values
  if ( IsValTok(a_iPos, tok) ) 
  {
    if (a_iSynFlags & noVAL) Error("No value expected:",  m_iPos);
    a_iSynFlags = noVAL | noVAR | noFUN | noBO | noINFIXOP;
    return tok;
  }

  // check String for variable
  if ( IsVarTok(a_iPos, tok) )
  {
    if (a_iSynFlags & noVAR) Error("No variable expected:",  m_iPos);
    a_iSynFlags = noVAL | noVAR | noFUN | noBO | noPOSTOP | noINFIXOP;
    return tok;
  }

  // check for unary operators
  if ( IsInfixOpTok(a_iPos, tok) )
  {
    if (a_iSynFlags & noINFIXOP) Error("No unary operator expected:",  m_iPos);
    a_iSynFlags = noPOSTOP | noINFIXOP | noOPT | noBC;
   	return tok;
  }

  // check for unary operators
  if ( IsPostOpTok(a_iPos, tok) )
  {
    if (a_iSynFlags & noPOSTOP) Error("No unary operator expected:",  m_iPos);
    a_iSynFlags = noVAL | noVAR | noFUN | noBO | noPOSTOP;
  	return tok;
  }

  // check String for undefined variable
  if ( m_bIgnoreUndefVar && IsUndefVarTok(a_iPos, tok) )
  {
    if (a_iSynFlags & noVAR) Error("No variable expected:",  m_iPos);
    a_iSynFlags = noVAL | noVAR | noFUN | noBO | noPOSTOP | noINFIXOP;
    return tok;
  }

  // check for unknown token
  char szBuf[256];
  int iStat = sscanf(&szFormula[a_iPos], "%[a-zA-Z0-9._]", &szBuf);
  int iLen = (iStat) ? (int)strlen(szBuf) : 1;

  Error("Unknown token found:", m_iPos + iLen);
  return tok;  // < can never be reached, just to avoid compiler warnings
}


//---------------------------------------------------------------------------
/** \brief Check whether the token at a given position is a function token.
  \param a_Tok [out] If a value token is found it will be placed here.
  \param a_iPos [in/out] Position within the formula, that should be checked for a value item.
  \return true if a function token has been found.
*/
bool ParserBase::IsFunTok(int &a_iPos, token_type &a_Tok) const
{
  const char *szFormula = m_strFormula.c_str();

  int iVarEnd = (int)strspn(&szFormula[a_iPos], c_NameChars);
  if (!iVarEnd) return false;

  string_type strFun(&szFormula[a_iPos], &szFormula[a_iPos+iVarEnd]);
  funmap_type::const_iterator item = m_FunDef.find(strFun);
  if (item!=m_FunDef.end())
  {
    // item->second = function prototype consisting of a pair made up of a pointer and argument count 
	a_Tok.SetFun(item->second.pFun,        // The function pointer
		         item->second.iArgc,       // the function argument count, determines implicitely the pointer type of item->pFun 
                 item->second.bAllowOpti); // flag indication optimizeability  

    a_iPos += iVarEnd;
	return true;
  }

  return false;
}


//---------------------------------------------------------------------------
/** \brief Check if a string position contains a unary post value operator. */
bool ParserBase::IsPostOpTok(int &a_iPos, token_type &a_Tok) const
{
  const char *szFormula = m_strFormula.c_str();

  int iVarEnd = (int)strspn(&szFormula[a_iPos], c_OprtChars);
  if (!iVarEnd) return false;

  string_type strOprt(&szFormula[a_iPos], &szFormula[a_iPos+iVarEnd]);

  optmap_type::const_iterator item = m_PostOprtDef.find(strOprt);
  if (item!=m_PostOprtDef.end())
  {
	a_Tok.SetPostOp((void*)item->second); 
	a_iPos += iVarEnd;
	return true;
  }

  return false;
}


//---------------------------------------------------------------------------
/** \brief Check if a string position contains a unary infix operator.

*/
bool ParserBase::IsInfixOpTok(int &a_iPos, token_type &a_Tok) const
{
  const char *szFormula = m_strFormula.c_str();
  int iVarEnd = (int)strspn(&szFormula[a_iPos], c_OprtCharsPrefix);
  if (!iVarEnd) return false;
  
  string_type strOprt(&szFormula[a_iPos], &szFormula[a_iPos+iVarEnd]);

  optmap_type::const_iterator item = m_InfixOprtDef.find(strOprt);
  if (item!=m_InfixOprtDef.end())
  {
	a_Tok.SetInfixOp((void*)item->second); 
	a_iPos += iVarEnd;
	return true;
  }

  return false;
}


//---------------------------------------------------------------------------
/** \brief Check whether the token at a given position is a value token.

  Value tokens are either values or constants.

  \param a_Tok [out] If a value token is found it will be placed here.
  \param a_iPos [in/out] Position within the formula, that should be checked for a value item.
  \return true if a value token has been found.
*/
bool ParserBase::IsValTok(int &a_iPos, token_type &a_Tok) const
{
#pragma warning( disable : 4244 )

  const char *szFormula = m_strFormula.c_str();

  if ( m_strFormula[a_iPos]=='+' || 
       m_strFormula[a_iPos]=='-' ) 
    return false;

  // 1.) Check for numeric value
  value_type fVal(0);
  int iCount(0);
  assert(sizeof(value_type)==sizeof(double));
  sscanf(szFormula+a_iPos, "%lf%n", &fVal, &iCount);
  if (iCount)
  {
    a_iPos += iCount;
    a_Tok.SetVal(fVal);
    return true;
  }

  // 2.) Check for user defined constant
  // Read everything that could be a constant name
  int iVarEnd = (int)strspn(&szFormula[a_iPos], c_NameChars);
  if (!iVarEnd) return false;

  string_type strVar(&szFormula[a_iPos], &szFormula[a_iPos+iVarEnd]);
  valmap_type::const_iterator item = m_ConstDef.find(strVar);
  if (item!=m_ConstDef.end())
  {
    a_iPos += iVarEnd;
    a_Tok.SetVal(item->second);
    return true;
  }

  return false;

#pragma warning( default : 4244 )
}


//---------------------------------------------------------------------------
/** \brief Check wheter a token at a given position is a variable token. 
    \param a_iPos [in/out] Position within the formula, that should be checked for a variable item.
    \param a_Tok [out] If a variable token has been found it will be placed here.
	\return true if a variable token has been found.
*/
bool ParserBase::IsVarTok(int &a_iPos, token_type &a_Tok) const
{
  if (!m_VarDef.size())
    return false;

  const char *szFormula = m_strFormula.c_str();

  // Read everything that could be a variable name
  char szVarName[128];
  int iStat = sscanf(&szFormula[a_iPos], "%64[0-9a-zA-Z_]", szVarName);
  if (!iStat) return false;

  // Check Variable list 
  int iVarEnd = (int)strspn(&szFormula[a_iPos], c_NameChars);
  if (!iVarEnd) return false;

  string_type strVar(&szFormula[a_iPos], &szFormula[a_iPos+iVarEnd]);
  varmap_type::const_iterator item = m_VarDef.find(strVar);
  if (item!=m_VarDef.end())
  {
    a_iPos += iVarEnd;
    a_Tok.SetVar(item->second);
    m_UsedVar[item->first] = item->second;  // Add variable to used-var-list
    return true;
  }

  return false;
}


//---------------------------------------------------------------------------
/** \brief Check wheter a token at a given position is a variable token. 
    \param a_iPos [in/out] Position within the formula, that should be checked for a variable item.
    \param a_Tok [out] If a variable token has been found it will be placed here.
	\return true if a variable token has been found.
*/
bool ParserBase::IsUndefVarTok(int &a_iPos, token_type &a_Tok) const
{
  const char *szFormula = m_strFormula.c_str();

  // Read everything that could be a variable name
  char szVarName[128];
  int iStat = sscanf(&szFormula[a_iPos], "%64[0-9a-zA-Z_]", szVarName);
  if (!iStat) return false;

  // Check Variable list 
  int iVarEnd = (int)strspn(&szFormula[a_iPos], c_NameChars);
  if (!iVarEnd) return false;

  string_type strVar(&szFormula[a_iPos], &szFormula[a_iPos+iVarEnd]);
  a_iPos += iVarEnd;
  a_Tok.SetVar((value_type*)&m_fZero);
  m_UsedVar[strVar] = 0;  // Add variable to used-var-list
  return true;
}

//---------------------------------------------------------------------------
/** \brief Get operator priority.

 \throw ParserException if a_Oprt is no operator code
*/
int ParserBase::GetOprtPri(const token_type &a_Tok) const
{
  switch (a_Tok.GetType())
  {
    case token_type::cmEND:   return -2;
  	case token_type::cmCOMMA: return -1;
    case token_type::cmBO :	
    case token_type::cmBC :   return 0;
    case token_type::cmAND:
    case token_type::cmOR:    return 1;  
    case token_type::cmLT :
    case token_type::cmGT :
    case token_type::cmLE :
    case token_type::cmGE :
    case token_type::cmNEQ:
    case token_type::cmEQ :   return 2; 
    case token_type::cmADD:
    case token_type::cmSUB:   return 3;
    case token_type::cmMUL:
    case token_type::cmDIV:   return 4;
    case token_type::cmPOW:   return 5;
    default:  Error("internal error in ParserBase::Priority(int):  unknown operator!");
	            return 0;
  }  
}

//---------------------------------------------------------------------------
/** \brief Return a map containing the used variables only. */
const ParserBase::varmap_type& ParserBase::GetUsedVar()
{
  try
  {
    m_bIgnoreUndefVar = true;
    ParseString(); // implicitely create or update m_UsedVar if not already done
    m_bIgnoreUndefVar = false;
  }
  catch(...)
  {
    m_bIgnoreUndefVar = false;
    throw;
  }
  
  // Do not change to bytecode mode, after all undefined variables may have been found
  m_pParseFormula = &ParserBase::ParseString;
  
  return m_UsedVar;
}

//---------------------------------------------------------------------------
/** \brief Apply an operator to two values.

  \param opt code of the operator to apply.
  \param x first value
  \param y second value
  \return x opt y (whatever opt means)
  \attention opt must be an operator code!
  \throw ParserException if opt is no operator token or either a_Val1 or a_Val2 is no value tokens.
*/
ParserBase::token_type ParserBase::ApplyOprt( const token_type &a_Val1, 
								                              const token_type &a_OptTok, 
								                              const token_type &a_Val2,
                                              int &a_iPos,
                                              int &a_iStackIdx ) const
{  
  value_type x = a_Val1.GetVal(),
	         y = a_Val2.GetVal();
  token_type tok;

  switch (a_OptTok.GetType())
  {
    case token_type::cmAND: tok.SetVal( x && y ); break;
    case token_type::cmOR:  tok.SetVal( x || y ); break;
    case token_type::cmLT:  tok.SetVal( x < y ); break;
    case token_type::cmGT:  tok.SetVal( x > y ); break;
    case token_type::cmLE:  tok.SetVal( x <= y ); break;
    case token_type::cmGE:  tok.SetVal( x >= y ); break;
    case token_type::cmNEQ: tok.SetVal( x != y ); break;
    case token_type::cmEQ:  tok.SetVal( x == y ); break;
    case token_type::cmADD: tok.SetVal( x + y ); break;
    case token_type::cmSUB: tok.SetVal( x - y ); break;
    case token_type::cmMUL: tok.SetVal( x * y ); break;
    case token_type::cmDIV: tok.SetVal( x / y ); break;
	  case token_type::cmPOW: tok.SetVal(pow(x, y)); break;
    default: Error("internal error in ParserBase::ApplyOperator(...): unexpected operator token.");
		     return tok; // never get there
  }
  
  if (!m_bOptimize)
  {
    // Optimization flag is not set
    m_pCmdCode[a_iPos++] = --a_iStackIdx;
    m_pCmdCode[a_iPos++] = a_OptTok.GetType();
  }
  else if ( a_Val1.IsFlagSet(token_type::flVOLATILE) || 
            a_Val2.IsFlagSet(token_type::flVOLATILE) )
  {
    // Optimization flag is not set, but one of the value
    // depends on a variable
    m_pCmdCode[a_iPos++] = --a_iStackIdx;
    m_pCmdCode[a_iPos++] = a_OptTok.GetType();

    tok.AddFlags(token_type::flVOLATILE);
    tok.SetDep( GetOprtPri(a_OptTok) );
  }
  else
  {
    // operator call can be optimized
    a_iPos -= 8; // overwrite the two previous CmdVAL entries
  	if (a_iPos<0) Error("internal error:  negative bytecode index (optimization).");
	  value_type fVal = tok.GetVal();
	  m_pCmdCode[a_iPos++] = --a_iStackIdx;
    m_pCmdCode[a_iPos++] = token_type::cmVAL;
    m_pCmdCode[a_iPos++] = *(reinterpret_cast<int*>(&fVal)    );
    m_pCmdCode[a_iPos++] = *(reinterpret_cast<int*>(&fVal) + 1);
  }

  assert(a_iStackIdx>=1);

  return tok;
}


//---------------------------------------------------------------------------
void ParserBase::ApplyInfixOp( ParserStack<token_type> &stOpt,
                               ParserStack<token_type> &stVal,
                               int &a_iPos, int &a_iStackIdx )const
{
#pragma warning( disable : 4311 ) 
    if (stOpt.empty() || stOpt.top().GetType()!=token_type::cmINFIXOP)
        return;

    if (stVal.empty())
        Error("internal error:  Unary operator applied to empty value stack.");

    token_type optTok = stOpt.pop(), 
               valTok = stVal.pop(),
               resTok;

    fun_type1 pFunc = (fun_type1)optTok.GetFuncAddr();
    assert(pFunc);
    
    resTok.SetVal( pFunc(valTok.GetVal()) );

    // optimization if the result does not depend on a variable (direct or indirect)
    if (m_bOptimize && ! valTok.IsFlagSet(token_type::flVOLATILE)) 
    {
        a_iPos -= 4; // function evaluation does'nt depend on a variable
	    if (a_iPos<0) 
            Error("internal error in ApplyUnaryOprt:  negative bytecode index (optimization).");

	    value_type fVal = resTok.GetVal();
	    m_pCmdCode[a_iPos++] = a_iStackIdx;
      m_pCmdCode[a_iPos++] = token_type::cmVAL;
      m_pCmdCode[a_iPos++] = *( reinterpret_cast<int*>(&fVal)     );
      m_pCmdCode[a_iPos++] = *( reinterpret_cast<int*>(&fVal) + 1 );
    }
    else
    {
      resTok.AddFlags( token_type::flVOLATILE );
      m_pCmdCode[a_iPos++] = a_iStackIdx;
      m_pCmdCode[a_iPos++] = token_type::cmPOSTOP;
      m_pCmdCode[a_iPos++] = reinterpret_cast<int>(pFunc);
    }

    stVal.push(resTok);

#pragma warning( default : 4311 ) 
}


//---------------------------------------------------------------------------
void ParserBase::ApplyFunction( int iArgCount,
                                ParserStack<token_type> &stOpt,
                                ParserStack<token_type> &stVal,
                                int &a_iPos, int &a_iStackIdx ) const
{ 
  if (stOpt.empty() || stOpt.top().GetType()!=token_type::cmFUNC)
    return;

  token_type funTok = stOpt.pop(), valTok;

  if ( funTok.GetArgCount()!=-1 && iArgCount>funTok.GetArgCount()) 
	  Error("Too many function parameter:", m_iPos);

	if ( iArgCount<funTok.GetArgCount() )
	  Error("Too few function parameter:", m_iPos);

  void *pFunc = funTok.GetFuncAddr();
  assert(pFunc);

  // Collect the function arguments from the value stack
  std::vector<token_type> stArg;  
  int i(0);
  for (i=0; i<iArgCount; ++i)
	  stArg.push_back( stVal.pop() );

  switch(funTok.GetArgCount())
  {
    case -1: // Function with variable argument count
 	     	     // copy arguments into a vector<value_type>
	        {
                /** \todo remove the unnecessary argument vector by changing order in stArg. */
                std::vector<value_type> vArg;
		        for (int i=0; i<(int)stArg.size(); ++i)
		          vArg.push_back(stArg[i].GetVal());

	            valTok.SetVal( ((multfun_type)funTok.GetFuncAddr())(vArg) );  
	        }
	        break;

    case 1: valTok.SetVal( ((fun_type1)funTok.GetFuncAddr())(stArg[0].GetVal()) ); break; 
    case 2: valTok.SetVal( ((fun_type2)funTok.GetFuncAddr())(stArg[1].GetVal(),
		                                                         stArg[0].GetVal()) ); break;
    case 3: valTok.SetVal( ((fun_type3)funTok.GetFuncAddr())(stArg[2].GetVal(), 
		                                                         stArg[1].GetVal(), 
														                                 stArg[0].GetVal()) ); break;
    case 4: valTok.SetVal( ((fun_type4)funTok.GetFuncAddr())(stArg[3].GetVal(), 
	                                                           stArg[2].GetVal(), 
				   	  	                                             stArg[1].GetVal(),
													                                   stArg[0].GetVal()) ); break;
    case 5: valTok.SetVal( ((fun_type5)funTok.GetFuncAddr())(stArg[4].GetVal(), 
														                                 stArg[3].GetVal(), 
	                                                           stArg[2].GetVal(), 
				   	  	                                             stArg[1].GetVal(),
													                                   stArg[0].GetVal()) ); break;
    default: Error("Unsupported number of arguments in funtion call");
    }

    // Find out if the result will depend on a variable
    /** \todo remove this loop, put content in the loop that takes the argument values. 
    
        (Attention: SetVal will reset Flags.)
    */
    bool bVolatile = funTok.IsFlagSet(token_type::flVOLATILE);
    for (i=0; (bVolatile==false) && (i<iArgCount); ++i)
      bVolatile |= stArg[i].IsFlagSet(token_type::flVOLATILE);

    if (bVolatile)
      valTok.AddFlags(token_type::flVOLATILE);

    // Store the result; create Bytecode
    stVal.push(valTok);
    a_iStackIdx = a_iStackIdx - (iArgCount-1); 

#pragma warning( disable : 4311 ) 

    // Formula optimization
    if (  m_bOptimize && 
         !valTok.IsFlagSet(token_type::flVOLATILE) && 
         !funTok.IsFlagSet(token_type::flVOLATILE) ) 
	{
	    a_iPos -= 4 * iArgCount; // function evaluation does'nt depend on a variable
	    if (a_iPos<0) Error("internal error:  negative bytecode index (optimization).");

	    value_type fVal = valTok.GetVal();
	    m_pCmdCode[a_iPos++] = a_iStackIdx;
	    m_pCmdCode[a_iPos++] = token_type::cmVAL;
	    m_pCmdCode[a_iPos++] = *( reinterpret_cast<int*>(&fVal)     );
	    m_pCmdCode[a_iPos++] = *( reinterpret_cast<int*>(&fVal) + 1 );
	}
	else 
	{ 
        // operation dosnt depends on a variable or the function is flagged unoptimizeable
        // we cant optimize here...
  	    m_pCmdCode[a_iPos++] = a_iStackIdx;
	    m_pCmdCode[a_iPos++] = token_type::cmFUNC;
	    m_pCmdCode[a_iPos++] = (funTok.GetArgCount()==-1) ? -iArgCount : iArgCount;
	    m_pCmdCode[a_iPos++] = reinterpret_cast<int>(pFunc);
	}

#pragma warning( default : 4311 ) 
}


//---------------------------------------------------------------------------
/** \brief Apply an unary operator. 
  
  Bytecode for the operation will be created and optimized if applicable.

  \param a_FunTok Operator token
  \param a_FunTok Value token to which the operator should be applied
  \param a_iPos Index into current bytecopde position
  \param a_iStackIdx Stack position the result will take
*/
ParserBase::token_type ParserBase::ApplyUnaryOprt(const token_type &a_FunTok, 
                                                  const token_type &a_ValTok,
                                                  int &a_iPos,
                                                  int &a_iStackIdx) const
{
#pragma warning( disable : 4311 ) 

  fun_type1 pFunc = (fun_type1)a_FunTok.GetFuncAddr();
  token_type result = pFunc( a_ValTok.GetVal() );
        
  // optimization if the result does not depend on a variable (direct or indirect)
  if (m_bOptimize && !a_ValTok.IsFlagSet(token_type::flVOLATILE)) 
  {
    a_iPos -= 4; // function evaluation does'nt depend on a variable
  	if (a_iPos<0) 
      Error("internal error in ApplyUnaryOprt:  negative bytecode index (optimization).");

  	value_type fVal = result.GetVal();
  	m_pCmdCode[a_iPos++] = a_iStackIdx;
    m_pCmdCode[a_iPos++] = token_type::cmVAL;
    m_pCmdCode[a_iPos++] = *( reinterpret_cast<int*>(&fVal)     );
    m_pCmdCode[a_iPos++] = *( reinterpret_cast<int*>(&fVal) + 1 );
  }
  else
  {
    result.AddFlags( token_type::flVOLATILE );
    m_pCmdCode[a_iPos++] = a_iStackIdx;
    m_pCmdCode[a_iPos++] = token_type::cmPOSTOP;
    m_pCmdCode[a_iPos++] = reinterpret_cast<int>(pFunc);
  }

  return result;
#pragma warning( default : 4311 ) 
}


//---------------------------------------------------------------------------
/** \brief Parse the command code.

  Command code contains precalculated stack positions of the values and the 
  associated operators.  
  The Stack is filled beginning from index one the value at index zero is
  not used at all.

  \sa ParseString(), ParseValue()
*/
ParserBase::value_type ParserBase::ParseCmdCode() const
{
#pragma warning( disable : 4312 )

  value_type Stack[300];
  int i(0), iCode(0), idx(0);

  __start:

  idx = m_pCmdCode[i]; 
  iCode = m_pCmdCode[i+1];
  i += 2;
  assert(idx<399); // Formula too complex

  switch (iCode)
  {
    case token_type::cmAND: Stack[idx]  = Stack[idx] && Stack[idx+1]; goto __start;
    case token_type::cmOR:  Stack[idx]  = Stack[idx] || Stack[idx+1]; goto __start;
    case token_type::cmLE:  Stack[idx]  = Stack[idx] <= Stack[idx+1]; goto __start;
    case token_type::cmGE:  Stack[idx]  = Stack[idx] >= Stack[idx+1]; goto __start;
    case token_type::cmNEQ: Stack[idx]  = Stack[idx] != Stack[idx+1]; goto __start;
    case token_type::cmEQ:  Stack[idx]  = Stack[idx] == Stack[idx+1]; goto __start;
	  case token_type::cmLT:  Stack[idx]  = Stack[idx] < Stack[idx+1];  goto __start;
	  case token_type::cmGT:  Stack[idx]  = Stack[idx] > Stack[idx+1];  goto __start;
    case token_type::cmADD: Stack[idx] += Stack[1+idx]; goto __start;
 	  case token_type::cmSUB: Stack[idx] -= Stack[1+idx]; goto __start;
	  case token_type::cmMUL: Stack[idx] *= Stack[1+idx]; goto __start;
	  case token_type::cmDIV: Stack[idx] /= Stack[1+idx]; goto __start;
	  case token_type::cmPOW: Stack[idx] = pow(Stack[idx], Stack[1+idx]); goto __start;

	  case token_type::cmVAR:
		     Stack[idx] = *( (value_type*)(m_pCmdCode[i]) );
		     ++i;
		     goto __start;
	
	  case token_type::cmVAL:
         Stack[idx] = *(value_type*)(&m_pCmdCode[i]);
 	       i += 2;
         goto __start;

	  case token_type::cmFUNC:	
		     {
		       int iArgCount = m_pCmdCode[i];
    		   
           switch(iArgCount)  // switch according to argument count
		       {
		         case 1: Stack[idx] = ((fun_type1)(m_pCmdCode[++i]))(Stack[idx]); break;
             case 2: Stack[idx] = ((fun_type2)(m_pCmdCode[++i]))(Stack[idx], Stack[idx+1]); break;
			       case 3: Stack[idx] = ((fun_type3)(m_pCmdCode[++i]))(Stack[idx], Stack[idx+1], Stack[idx+2]); break;
			       case 4: Stack[idx] = ((fun_type4)(m_pCmdCode[++i]))(Stack[idx], Stack[idx+1], Stack[idx+2], Stack[idx+3]); break;
			       case 5: Stack[idx] = ((fun_type5)(m_pCmdCode[++i]))(Stack[idx], Stack[idx+1], Stack[idx+2], Stack[idx+3], Stack[idx+4]); break;
             default:
				        if (iArgCount<=0) // function with variable arguments store the number as a negative value
				        {
					        std::vector<value_type> vArg(&Stack[idx], &Stack[idx-iArgCount]);
					        Stack[idx] =((multfun_type)(m_pCmdCode[++i]))(vArg); break;
				        }
				        else
				        {
				            Error("internal error:  Unsupported number of arguments in function call.");
				        }
		    }
		    ++i;
		   }
		   goto __start;

	  case token_type::cmPOSTOP:
	       Stack[idx] = ((fun_type1)(m_pCmdCode[i]))(Stack[idx]);
	       ++i;
    	   goto __start;

	  case token_type::cmEND: 
		     return Stack[1];

	  default: 
		     Error( "internal error in ParserBase::ParseCmdCode(...) :  unexpected or unknown CmdCode" );
         return 0;
  }

#pragma warning( default : 4312 )
}


//---------------------------------------------------------------------------
/** \brief Return result for constant functions. 

  Seems pointless, but for parser functions that are made up of only a value, which occur 
  in real world applications, this speeds up thing by removing the parser overhead almost 
  completely.
*/
ParserBase::value_type ParserBase::ParseValue() const
{
  return *(value_type*)(&m_pCmdCode[2]);
}


//---------------------------------------------------------------------------
/** \brief One of the two main parse functions.

 Parse expression from input string. Perform syntax checking and create bytecode.
 After parsing the string and creating the bytecode the function pointer 
 #m_pParseFormula will be changed to the second parse routine the uses bytecode instead of string parsing.

 \sa ParseCmdCode(), ParseValue()
*/
ParserBase::value_type ParserBase::ParseString() const
{ 
#pragma warning( disable : 4311 ) 

  if (!m_strFormula.length()) 
      Error("Formula string is empty.");

  // create new space for the bytecode
  delete [] m_pCmdCode;
  int iSize = 2 + (int)m_strFormula.length() * 5;

  // Command code cannot be longe then 10 times formula length, in fact it will be much shorter
  // make sure to allocate at least 4 integer.
  m_pCmdCode = new int[iSize];
  memset(m_pCmdCode, 0, iSize*sizeof(token_type::ECmdCode));

  m_iPos = 0;         // global formula position index
  m_UsedVar.clear();  // Clear the map holding the variables actually used in an expression

  ParserStack<token_type> stOpt, stVal;
  ParserStack<int> stArgCount;
  token_type opta, opt;  // for storing operators
  token_type val, tval;  // for storing value
  int  iSynCtrl = noOPT | noBC | noPOSTOP, 
       iErrc, 
       iBrackets(0), // bracket level counter
       iBytePos(0),  // bytecode index
       iStack(0);    // 'recorded' stack position
  
#pragma warning( disable : 4127 )
  while (true)
#pragma warning( default : 4127 )
  {
    opt = ReadToken(m_iPos, iSynCtrl);

    switch (opt.GetType())
    {
      case token_type::cmVAR:
		   stVal.push(opt);
           m_pCmdCode[iBytePos++] = ++iStack;
           m_pCmdCode[iBytePos++] = token_type::cmVAR;
           m_pCmdCode[iBytePos++] = reinterpret_cast<int>(opt.GetVar());
           ApplyInfixOp(stOpt, stVal, iBytePos, iStack);
           break;

      case token_type::cmVAL:
		   {
			 stVal.push(opt);
			 value_type fVal = opt.GetVal();
             m_pCmdCode[iBytePos++] = ++iStack;
             m_pCmdCode[iBytePos++] = token_type::cmVAL;
             m_pCmdCode[iBytePos++] = *( reinterpret_cast<int*>(&fVal)     );
             m_pCmdCode[iBytePos++] = *( reinterpret_cast<int*>(&fVal) + 1 );
             ApplyInfixOp(stOpt, stVal, iBytePos, iStack);
		   }            
		   break;

      case token_type::cmBC:    // For closing brackets make some syntax checks
		             if ( --iBrackets < 0 )  
						 Error("No opening bracket for the last closing one found: ", m_iPos);
					 // no break; Fall through behaviour!
      case token_type::cmCOMMA:
      case token_type::cmEND:	
      case token_type::cmAND:
      case token_type::cmOR:
      case token_type::cmLT:
      case token_type::cmGT:
      case token_type::cmLE:
      case token_type::cmGE:
      case token_type::cmNEQ:
      case token_type::cmEQ:
      case token_type::cmADD:
      case token_type::cmSUB:
      case token_type::cmMUL:
      case token_type::cmDIV:
      case token_type::cmPOW:
  		    if (opt.GetType()==token_type::cmCOMMA)
			{
			  if (stArgCount.empty())
				  Error("Comma used without a function", m_iPos);
              ++stArgCount.top(); // Record number of arguments
			}
            
			// There must be at least two operator tokens  available before we can start
		    // the calculation. It's necessary to compare their priorities
			// Get the previous operator from the operator stack in order to find
		    // out if this operator can be applied (must have a higher priority)
   		    opta = stOpt.pop(iErrc);
            if ( iErrc && opt.GetType()!=token_type::cmEND )
            {
              stOpt.push(opt);
              break;
            }

			// Order does matter in the while statement because Priority will fail
			// if errc is set!
			while ( opta.GetType()!=token_type::cmBO && 
				    opta.GetType()!=token_type::cmCOMMA && 
					!iErrc && 
					GetOprtPri(opta)>=GetOprtPri(opt)  )
            {
			  tval = stVal.pop(iErrc);  
              val  = stVal.pop(iErrc); 
              if (iErrc) Error("internal error: value stack empty!");

              stVal.push( ApplyOprt(val, opta, tval, iBytePos, iStack) );
			  opta = stOpt.pop(iErrc);
            } // while ( ... )

            // if opt is ")" and opta is "(" the bracket has been evaluated, now its time to check
			// if there is either a function or a sign pending
			// neither the opening nor the closing bracket will be pushed back to
			// the operator stack
            if ( (opta.GetType()==token_type::cmBO && opt.GetType()==token_type::cmBC) )
            {
			  // Check if a function is standing in front of the opening bracket, 
              // if yes evaluate it afterwards check for infix operators
			  assert(stArgCount.size());
			  int iArgCount = stArgCount.pop();
              ApplyFunction(iArgCount, stOpt, stVal, iBytePos, iStack);
              ApplyInfixOp(stOpt, stVal, iBytePos, iStack);
              break;
			} // if bracket content is evaluated

		    if (!iErrc) 
				stOpt.push(opta);
            
			// The operator can't be evaluated right now, push back to the operator stack 
			// CmdEND, CmdCOMMA will not be pushed back, they have done their job now
			// (and triggerd evaluation of the formula or an expression used as function argument)
			if (opt.GetType()!=token_type::cmEND && opt.GetType()!=token_type::cmCOMMA) 
				stOpt.push(opt);
            break;

	  case token_type::cmBO:    ++iBrackets;  stArgCount.push(1);
	  case token_type::cmFUNC:
      case token_type::cmINFIXOP:
            stOpt.push(opt);
			break;

	  case token_type::cmPOSTOP: // Postfix operators will be treated like functions
			val = stVal.pop(iErrc);
		    if (iErrc)
                Error("internal error:  stack empty.");

            stVal.push( ApplyUnaryOprt(opt, val, iBytePos, iStack) );
		    break;

	  default: Error("internal error:  unsupported operator/function used");
    } // end of switch operator-token

    if ( opt.GetType() == token_type::cmEND )
    {
      m_pCmdCode[iBytePos++] = token_type::cmEND;	
      m_pCmdCode[iBytePos++] = token_type::cmEND;	
      m_pCmdCode[iBytePos++] = token_type::cmEND;	
      break;
    }

    assert(iBytePos<iSize);  // we have exceeded the allocated memory

#if defined(MU_PARSER_DUMP_STACK)
  ParserDebug::StackDump(stVal, ops);
#endif
  } // while (true)

#if defined(MU_PARSER_DUMP_CMDCODE)
  ParserDebug::DumpCmdCode(m_pCmdCode);
#endif

  // check bracket counter
  if (iBrackets>0) 
      Error("parse error:  missing \")\"");

  // get the last value (= final result) from the stack
  val = stVal.pop(iErrc);
  if (iErrc)
      Error("No formula set.");

  if (stVal.size())
      Error("internal error:  missing operator.");

  // no error, so change the function pointer for the main parse routine
  value_type fVal = val.GetVal();   // Result from String parsing
  if (!m_bUseByteCode)
      return fVal; // returning here prevents switching to bytecode parsing mode

  // Constant result? If yes even bytecode parsing is pointless...
  if (m_pCmdCode[1]==token_type::cmVAL && m_pCmdCode[6]==token_type::cmEND)
    m_pParseFormula = &ParserBase::ParseValue;
  else
    m_pParseFormula = &ParserBase::ParseCmdCode;
  
  return fVal;

#pragma warning( default : 4311 )
} 


//---------------------------------------------------------------------------
/** \brief create an error containing the parse error position.

  This function will create an Parser Exception object containing the error text and its position.

  \throw ParserException, always throws thats the only purpose of this function.
*/
void ParserBase::Error(const string_type &a_strMsg, int idx) const
{
  string_type strError = a_strMsg;

  if (idx>=0 && m_strFormula.length())
  {
    string_type strFormula = m_strFormula;
    if (idx) strFormula[idx] = 0;
	strError = strError + " " + strFormula;
	if (idx) strError = strError	+ " <- here";
  }

  m_pParseFormula = &ParserBase::ParseString;
  throw ParserException(strError, m_strFormula);
}


//------------------------------------------------------------------------------
/** \brief Clear all user defined variables.
\post Resets the parser to string parsing mode.
\throw nothrow
*/
void ParserBase::ClearVar()
{
  m_VarDef.clear();
  m_pParseFormula = &ParserBase::ParseString;
}


//------------------------------------------------------------------------------
/** \brief Clear the formula. 

Clear the formula and existing bytecode.

\post Resets the parser to string parsing mode.
\throw nothrow
*/
void ParserBase::ClearFormula()
{
  delete [] m_pCmdCode;
  m_pCmdCode = 0;

/* <bugfix> for MSVC 6 
  m_strFormula.clear(); 
/* replaced with: */
  m_strFormula = "";
/* </bugfix> */

  m_pParseFormula = &ParserBase::ParseString;
}


//------------------------------------------------------------------------------
/** \brief Clear all functions. 
    \post Resets the parser to string parsing mode.
    \throw nothrow
*/
void ParserBase::ClearFun()
{
  m_FunDef.clear();
  m_pParseFormula = &ParserBase::ParseString;
}


//------------------------------------------------------------------------------
/** \brief Clear all user defined constants.
    \post Resets the parser to string parsing mode.
    \throw nothrow
*/
void ParserBase::ClearConst()
{
  m_ConstDef.clear();
  m_pParseFormula = &ParserBase::ParseString;
}


//------------------------------------------------------------------------------
/** \brief Clear all user defined postfix operators.
    \post Resets the parser to string parsing mode.
    \throw nothrow
*/
void ParserBase::ClearPostfixOp()
{
  m_PostOprtDef.clear();
  m_pParseFormula = &ParserBase::ParseString;
}


//------------------------------------------------------------------------------
/** \brief Clear the user defined Prefix operators. 
    \post Resets the parser to string parser mode.
    \throw nothrow
*/
void ParserBase::ClearPrefixOp()
{
  m_InfixOprtDef.clear();
  m_pParseFormula = &ParserBase::ParseString;
}


//------------------------------------------------------------------------------
/** \brief Enable or disable the formula optimization feature. 
    \post Resets the parser to string parser mode.
    \throw nothrow
*/
void ParserBase::EnableOptimizer(bool a_bIsOn)
{
  m_bOptimize = a_bIsOn;
  m_pParseFormula = &ParserBase::ParseString;
}


//------------------------------------------------------------------------------
/** \brief Enable or disable parsing from Bytecode. 

  \attention There is no reason for doing this. It will 
             drastically decrease parsing speed.
*/
void ParserBase::EnableByteCode(bool a_bIsOn)
{
  m_bUseByteCode = a_bIsOn;

  if (!a_bIsOn)
      m_pParseFormula = &ParserBase::ParseString;
}

} // namespace MathUtils
