#include "muParserTest.h"

#define _USE_MATH_DEFINES		/* schaltet math.h Konstanten frei  */	

#include <cstdlib>
#include <cstring>
#include <cmath>
#include <string>
#include <iostream>

#include "muParser.h"

#if defined(_DEBUG)
  #pragma comment(lib, "../ParserLib/muParserDbg.lib")
#else
  #pragma comment(lib, "../ParserLib/muParser.lib")
#endif

using namespace std;


// unary operator callbacks
double Milli(double a_fVal) { return a_fVal / 1e3; }
double Micro(double a_fVal) { return a_fVal / 1e6; }
double Nano(double a_fVal)  { return a_fVal / 1e9; }
double Rnd(double v) { return v*rand()/(RAND_MAX+1.0); }

double Sign(double v) { return -v; }


int main(int argc, char* argv[])
{
    std::cout << "---------------------------------------\n";
    std::cout << "\n";
    std::cout << "  Math Parser sample application\n";
    std::cout << "\n";
    std::cout << "---------------------------------------\n";

    MathUtils::Test::ParserTester pt;
    pt.Run();

    std::cout << "---------------------------------------\n";
    std::cout << "Functions:\n";
    std::cout << "  min(x,y) return minimum of x and y\n";
    std::cout << "  max(x,y) return maximum of x and y\n";
    std::cout << "  avg(...) return mean value of all input svalues\n";
    std::cout << "  sum(...) return sum of input values\n";
    std::cout << "Postfix operators:\n";
    std::cout << "  \"m\"  milli - divide by 1e3\n";
    std::cout << "  \"mu\" micro - divide by 1e6\n";
    std::cout << "  \"n\"  nano  - divide by 1e9\n";
    std::cout << "Constants:\n";
    std::cout << "  \"_e\"   2.718281828459045235360287\n";
    std::cout << "  \"_pi\"  3.141592653589793238462643\n";
    std::cout << "---------------------------------------\n";
    std::cout << "Please enter a formula:\n";

    double fVal1 = 1, 
	       fVal2 = 2, 
		   fVal3 = 3;
    double fRes1 = 0;
    std::string strFormula;

    MathUtils::Parser parser;

    // Add some variables
    double vVarVal[] = { 1, 2, 3, 4, 5 }; // Values of the parser variables
    try
    {
        parser.AddVar("a", &vVarVal[0]);      // Assign Variable names and bind them to the C++ variables
        parser.AddVar("b", &vVarVal[1]);

        // Add user defined unary operator
        parser.AddPostfixOp("m", Milli);
        parser.AddPostfixOp("mu", Micro);
        parser.AddPostfixOp("n", Nano);

        parser.AddPrefixOp("-", Sign);

        // Add an unoptimizeable function
        parser.AddFun("rnd", Rnd, false);

        // set optimizer state (defaults to true)
        parser.EnableOptimizer(true);
    }
    catch(MathUtils::ParserException &e)
    {
      cout << e.what() << "\n";
    }

    if (argc==1)
    {
        char line[100];
        bool bRunning(true);

        while(bRunning)
        {
            try
            {
                while ( fgets(line, 99, stdin) )
                {
                    if (!strncmp("quit", line, 4))
                    {
                        bRunning = false;
                        break;
                    }
                    else
                    {
                        strFormula = line;
                        parser.SetFormula(strFormula);
                       
#define PARSER_DIFF
#ifdef PARSER_DIFF                        
                        // Query the used variables (must be done after calc)
                        MathUtils::Parser::varmap_type UsedVar = parser.GetUsedVar();
                        if (UsedVar.size())
                        {
                          cout << "NumVar: " << (int)UsedVar.size() << "\n";
                          MathUtils::Parser::varmap_type::const_iterator item = UsedVar.begin();
                          for (; item!=UsedVar.end(); ++item)
                          {
                            cout << item->first << " [0x" << item->second << "]\n";
                          } // for all used variables
                        } // if used variables exist

//                        fRes1 = parser.Diff(&vVarVal[0], 1);
//	                      cout << "d(formula)/d(a)|a=0 = " << fRes1 << "\n";
#endif

	                    fRes1 = parser.Calc();
	                    cout << fRes1 << "\n";
                      cout << "Ready\n";
                    }
                }
            }
            catch(MathUtils::ParserException &e)
            {
                cout << e.what() << "\n";
            }
        } // while running
    }

    return 0;
}
