#using <mscorlib.dll>

#include "stdafx.h"
#include "WndMain.h"
#include <windows.h>

// Make sure to link the correct library
// This depends on wheteher debug mode is active and the current
// threading model
//#if defined(_DEBUG)
//  #pragma comment(lib, "../ParserLib/muParserMT_Dbg.lib")
//#else
//  #pragma comment(lib, "../ParserLib/muParserMT.lib")
//#endif

#pragma comment(lib, "../ParserLib/muParser.lib")

// Undefine The Microsoft MessageBox macro in order
// to make the Microsoft MessageBox class work
#pragma push_macro("MessageBox")
#undef MessageBox

using namespace Example2;
using namespace System::Windows::Forms;
using namespace System::Runtime::InteropServices;

int APIENTRY _tWinMain(HINSTANCE, HINSTANCE, LPTSTR, int)
{

  try
  {
    System::Threading::Thread::CurrentThread->ApartmentState = System::Threading::ApartmentState::STA;
	  Application::Run(new WinCalc());
  }
  catch(SEHException *e)
  {
    MessageBox::Show(e->Message);
  }
  catch(System::Exception *e)
  {
    MessageBox::Show(e->Message);
  }
  catch(...)
  {
    MessageBox::Show("Unexpected exception");
  }

	return 0;
}

#pragma pop_macro("MessageBox")
